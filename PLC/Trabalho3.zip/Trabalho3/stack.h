#ifndef _STACK_
#define _STACK_
#define MAXSIZE 100

struct STACK
{
    int stk[MAXSIZE];
    int sp;
};

typedef struct STACK* stack;

int top(stack s);
void push(stack s, int elem);
int pop();
stack initStack();

#endif