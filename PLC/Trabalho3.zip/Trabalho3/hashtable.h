
#define HASHTABLE_H

#include <stdbool.h>

typedef struct hashtable *HashTable;
typedef struct node *table;


HashTable createHashTable(const unsigned int capacity);

void destroyHashTable(HashTable h);

HashTable addHashTable(HashTable h, char *key, int address, int type);

table get_HashTable(HashTable hashtbl, char *key);

int getEndereco(const HashTable h, char *key);

int getInicializacao(const HashTable h, char *key);

int getType(const HashTable, char*);

